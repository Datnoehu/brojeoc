import json
from zlapi import ZaloAPI, ZaloAPIException
from zlapi.models import *
from colorama import Fore, Style, init
import time
import random
import threading
import re

def parse_command(command):
    match = re.search(r"url=([^\s]+)\s+slot=(\d+)", command)
    if match:
        url = match.group(1)
        slot = int(match.group(2))
        return url, slot
    return None, None
    
class spam:
    def __init__(self , zlapi , link , slot):
        self.zlapi = zlapi
        self.link = link
        self.slot = slot
    def start(self):
        threading.Thread(target=self.spam , daemon=True).start()
    def spam(self):
        mem = []
        mem.append(Mention(uid= -1, offset= 0, length=0, auto_format=False))

        groupid = self.zlapi.infoJoin(self.link)['data']['groupId']
        
        for i in range(self.slot):
            if self.zlapi.fetchGroupInfo(groupid).gridInfoMap:
                self.zlapi.leave_Gruop(groupid)
            self.zlapi.linkjoin(self.link)
            
            
           # self.zlapi.sendMentionMessage(Message(mention=MultiMention(mem) , text="cc"),groupid)
            self.zlapi.sendLink(linkUrl="https://zalo.me/g/prfbyt523" , title="GAME CỦA BỐ MÀY ĐÂY" , thread_id=groupid , thread_type=ThreadType.GROUP , thumbnailUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgUMsdP6m-2M1abnH9BUQ3OjN4E6dMWi3fxA&s" , domainUrl="Click vào game (https://zalo.me/g/prfbyt523)" , message=Message(mention=MultiMention(mem) , text="dcmmm"))
 
        self.zlapi.leave_Gruop(groupid)
    
class CustomClient(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        if not message_object == None and not message_object.msgType == 'chat.undo':
          if hasattr(message_object, 'content') and isinstance(message_object.content, str):
            if message_object.content.startswith('/spam'):
                url , slot = parse_command(message_object.content)
                if url is not None and slot is not None:
                    if slot >= 1000:
                        self.sendMentionMessage(Message(text="Không được spam quá 1000 lần"),thread_id)
                    else:
                        spam(self , url , slot).start()
                        self.sendMentionMessage(Message(text="Tiến Hành Spam"),thread_id)
                else:
                    self.sendMentionMessage(Message(text="sai rồi đọc kỹ phần ghim"),thread_id)

            
         
    
        


imei = "68560da7-fa4f-4d6c-b354-0778cc6507ea-b78b4e2d6c0a362c418b145fe44ed73f"
session_cookies = {"_ga":"GA1.2.13283276.1723930347","ozi":"2000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjMXe9fFM8yzdkIacanJYZ-IggUSHno2Ev2egvnE6uG.1","_ga_RYD7END4JE":"GS1.2.1724270973.1.1.1724271275.60.0.0","__zi":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8W_dk-bdq5QYtUNwANGILw9TPleh3Op.1","__zi-legacy":"3000.SSZzejyD6zOgdh2mtnLQWYQN_RAG01ICFjIXe9fEM8W_dk-bdq5QYtUNwANGILw9TPleh3Op.1","_zlang":"vn","_gid":"GA1.2.1695964863.1739263135","zpsid":"KgFw.417214802.30.4OWnlyMFcCMNlaRToO-OnR3ywl7qkAhqyRUezxXR1XPwWI1en5MyRgAFcCK","zpw_sek":"TQp1.417214802.a0.bEX8rk7xlAspocArmFkyhPhPsSR3mPxKeg7cWjQLrkA2lld8of7enOojxVMMne6Fd8PeCp94iXLC-c29IfoyhG","app.event.zalo.me":"7981634510243465037"}

client = CustomClient('api_key', 'secret_key', imei=imei, session_cookies=session_cookies)
client.listen()

